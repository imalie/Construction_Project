@extends('layouts.app')


@section('content')
    <h1>profile page</h1>
        
@endsection
